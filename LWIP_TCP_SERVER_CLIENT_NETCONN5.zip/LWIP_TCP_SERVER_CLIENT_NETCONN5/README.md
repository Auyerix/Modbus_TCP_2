Proyecto base FreeRTOS + LIWP + Server (plain communication)
